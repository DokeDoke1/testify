// import React, { Component } from "react";
// class Footer extends Component() {
//   constructor(props) {
//     super(props);
//     this.setState ( {
//     title: "ЮРИДИЧЕСКАЯ ИНФОРМАЦИЯ",
//     textfirst: "Конфиденциальность",
//     textsecond: "Условия",
//     textthird: "Политика в отношении файлов Cookie",
//     textfour: "Интеллектуальная Собственность",
//     })
//     }
    


//     render(){
//       return (
        
//       <div className="Body2">
//         <div className='Footer'></div>
//         <h3 className="f1">{this.state.title}</h3>
//         <h3>Privet {this.state.textfirst}</h3>
//         <h3>{this.state.textsecond}</h3>
//         <h3>{this.state.textthird}</h3>
//         <h3>{this.state.textfour}</h3>
//       </div>
//     );}
//   }
// export default Footer;