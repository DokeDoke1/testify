import React from "react";
function Header() {
    return (
      <div className="Body">
        <div className='Header'>
          <div className='Logo'></div>
          <div className='Logo1'>Клиентам</div>
          <div className='Logo2'>Бизнесу</div>
          <div className='Logo3'>Каспи Гид</div>
          <div className='BodyLogo'>
         <div className='BodyLogo1'></div>
         <div className='BodyLogo2'></div>
        </div>
        </div>
        
      </div>
    );
  }
export default Header;